package com.example.myapp;

import android.app.Application;

import com.parse.Parse;
import com.parse.ParseInstallation;

public class ParseApplication extends Application {

    @Override
    public void onCreate()
    {
        super.onCreate();
        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("CjbzoyxdXmKVKcnqgd3ZBaqewk2TZ2iMRLWfm2Zx")
                .clientKey("ykdmbrSzoeU76PQuJUyf0qGZrFADFbhWjLaorwhc")
                .server("https://parseapi.back4app.com")
                .build()
        );

        ParseInstallation.getCurrentInstallation().saveInBackground();
    }
}
