package com.example.myapp.Activites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapp.LoginActivity;
import com.example.myapp.R;
import com.parse.CountCallback;
import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import java.util.ArrayList;
import java.util.List;

public class RegisterActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etEmail;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private Button btnRegister;
    private TextView tvLogin;
    private TextView tvRegister;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername = findViewById(R.id.etUsername);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);
        tvLogin = findViewById(R.id.tvLogin);
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginIntent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(loginIntent);
            }
        });
        //registers authorized user
        tvRegister = findViewById(R.id.tvRegister);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent moveToAURegister = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(moveToAURegister);
            }
        });

        //registers user
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // username attempt 1
                /*
                //final ParseQuery<ParseUser> emailQuery = ParseUser.getQuery();
                //emailQuery.whereEqualTo("email", etEmail);
                final ParseQuery<ParseUser> usernameQuery = ParseUser.getQuery();
                usernameQuery.whereEqualTo("username", etUsername);
                List<ParseQuery> queries = new ArrayList<>();
                //queries.add(emailQuery);
                queries.add(usernameQuery);
                final ParseQuery<ParseUser> query = ParseQuery.or(queries);
                query.findInBackground(new FindCallback<ParseUser>() {
                    public void done(List<ParseUser> results, ParseException e) {
                        // results has the list of users that match either the email address or username
                    }
                });
                 */
                //tests if duplicated username
                final ParseUser user = new ParseUser();
                /*
                ParseQuery<ParseUser> query = ParseUser.getQuery();
                query.whereEqualTo("username", etUsername);
                query.countInBackground(new CountCallback(){

                    @Override
                    public void done(int count, ParseException e) {
                        // TODO Auto-generated method stub
                        if (e == null) {
                            if(count==0){
                                //Username doesnt exit

                                Log.i("RegisterActivity", "Not A Duplicate User");
                            }
                            else
                            {
                                Toast.makeText(RegisterActivity.this, "Sorry This Username has already been taken. ",Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                });

                 */

                // tests for the username preexist
                /*
                    ParseObject db = new ParseObject("User");
                    db.put("username",etUsername);
                    db.put("password",etPassword);
                    db.saveInBackground();
                    // this is create query of your parse table
                    ParseQuery<ParseObject> query = new ParseQuery<>("User");
                    //query.whereEqualTo(YourParseColumeNameEmail, yourEmail);
                    //query.whereEqualTo(YourParseColumeNamePassword, yourPassword);
                     query.whereEqualTo("username",etUsername);
                    // this is for doing in background
                    query.findInBackground(new FindCallback<ParseObject>() {
                    public void done(List<ParseObject> scoreList, ParseException e)
                    {
                        if (e == null) {
                            if (scoreList.size() == 0)
                            {
                               // if there is no data like your email and password then it,s come here
                               //set username
                                user.setUsername(String.valueOf(etUsername));
                            }
                            else
                            {
                                // if there is data like your email and password then it,s come here
                                Toast.makeText(RegisterActivity.this, "Sorry This Username has already been taken. ",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {
                        Log.d("score", "Error: " + e.getMessage());
                        }
                    }
                    });
                     */
                    //boolean isAuthorized = user.getBoolean("AuthorizedUser");
                /*
                    ParseQuery<ParseObject> query = ParseQuery.getQuery("User");
                    query.getInBackground(new GetCallback<ParseObject>() {
                        @Override
                        public void done(ParseObject object, ParseException e)
                        {
                            if (e == null)
                            {
                                // object will be your game score
                            }
                            else
                            {
                                // something went wrong
                            }
                        }
                    });
                 */


                // Set the user's username and password, which can be obtained by a forms
                //tests if passwords are the same
                if (etPassword.toString().equals(etConfirmPassword.toString()))
                {
                    user.setPassword(String.valueOf(etPassword));
                    user.signUpInBackground(new SignUpCallback() {
                        @Override
                        public void done(ParseException e) {
                            if (e == null) {
                                // so if this is true then we add user and password to our database
                                //alertDisplayer("Sucessful Sign Up!","Welcome" + etUsername + "!");
                                //Toast.makeText(RegisterActivity.this, "d","")
                                Toast.makeText(RegisterActivity.this, "Successfully Signed Up, Welcome " + etUsername.toString() + "!" , Toast.LENGTH_SHORT).show();
                                Log.i("RegisterActivity", "Signed up?");
                                Intent moveToLogin = new Intent(RegisterActivity.this,LoginActivity.class);
                                startActivity(moveToLogin);
                            }
                            else
                            {
                                ParseUser.logOut();
                                Toast.makeText(RegisterActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
                else // passwords do not match
                {
                    Toast.makeText(RegisterActivity.this, "Passwords Do not Match",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

/*
    private void alertDisplayer(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.class)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        // don't forget to change the line below with the names of your Activities
                        Intent intent = new Intent(RegisterActivity.this, LoginActivity.logoutUser());
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                });
        AlertDialog ok = builder.create();
        ok.show();
    }

 */
}