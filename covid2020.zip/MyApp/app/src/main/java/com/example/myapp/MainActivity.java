package com.example.myapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {


    private BottomNavigationView bottomNavigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottomNavigationView = findViewById(R.id.bottomNavigation);


        View btnLogOut = findViewById(R.id.btnLogout);

        //queryPosts();

        ///*
        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginActivity login = new LoginActivity();
                login.logoutUser();
            }
        });//*/


        /*
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemSelectedListener()
       {
           @Override

           public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
           {
               Fragement fragment;
               switch(menuItem.getItemId())
               {

               }


               return true;
           }
       });


         */


    }
}