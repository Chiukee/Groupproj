package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapp.Activites.RegisterActivity;
import com.parse.GetCallback;
import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

/*****************
This Login Activity is Shared Between A regular user and an Authorized User
They Both Shared the same login functionalitly including loging out
 Howwever, Once logged in it determines if a user is an Authorized User Via Boolean Logic
 From there it will take them to either Main Activity or AUMainActivity
 ***/
public class LoginActivity extends AppCompatActivity
{
    public static final String TAG = "LoginActivity";
    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvRegister;
    //boolean isAuthorized;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (ParseUser.getCurrentUser() != null)
        {
            goMainActivity();
        }

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG, "onClick login button");
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                //boolean isCurrentUser =
                loginUser(username, password);
            }
        });
        tvRegister = findViewById(R.id.tvRegister);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent registerIntent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(registerIntent);
            }
        });
    }

    private void loginUser(String username, String password)
    {
        Log.i(TAG,"Attempting to login user" + username);
        ParseUser currentUser = ParseUser.getCurrentUser();
        ParseObject user = new ParseObject("User");
        

        if(isAnAuthorizedUser(user))
        {

            ParseUser.logInInBackground(username, password, new LogInCallback() {
                @Override
                public void done(ParseUser user, ParseException e) {
                    if (e != null) {
                        //TODO: better error handling
                        Log.e(TAG, "Issue with Login", e);
                        Toast.makeText(LoginActivity.this, "Issue with login", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // Authorized User Has Been Verified and logs into the Authorized User Main Activtity
                    Toast.makeText(LoginActivity.this, "Success!", Toast.LENGTH_SHORT);
                    Intent AULogin = new Intent(LoginActivity.this,AUMainActivity.class);
                    startActivity(AULogin);
                }
            });

        }

        else

        {
            ParseUser.logInInBackground(username, password, new LogInCallback() {
                @Override
                public void done(ParseUser user, ParseException e) {
                    if (e != null) {
                        //TODO: better error handling
                        Log.e(TAG, "Issue with Login", e);
                        Toast.makeText(LoginActivity.this, "Issue with login", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    //TODO: navigates to main activity when user signs in correctly
                    goMainActivity();
                    Toast.makeText(LoginActivity.this, "Success!", Toast.LENGTH_SHORT);
                }
            });
        }
    }

    
    public void logoutUser()
    {
        ParseUser.logOut();
        ParseUser currentUser = ParseUser.getCurrentUser();
        finish();
        //goMainActivity();
    }

    public boolean isAnAuthorizedUser(final ParseObject user)
    {
        final boolean[] temp = new boolean[1];
        final ParseQuery<ParseObject> query = ParseQuery.getQuery("_User");
        query.getInBackground("DUwe7oINGi", new GetCallback<ParseObject>() {
            @Override
            public void done(ParseObject object, ParseException e)
            {
                if (e == null)
                {
                    // object will be your game score
                    boolean isAuthorized = user.getBoolean("AuthorizedUser");
                    temp[0] = retBool(isAuthorized);

                }
                else
                {
                    // something went wrong
                }
            }
        });



        //boolean isAuthorized = user.getBoolean("AuthorizedUser");
        //return isAuthorized;
        return temp[0];
    }

    private boolean retBool (boolean ans)
    {
        return ans;
    }


    private void goMainActivity()
    {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }

}
